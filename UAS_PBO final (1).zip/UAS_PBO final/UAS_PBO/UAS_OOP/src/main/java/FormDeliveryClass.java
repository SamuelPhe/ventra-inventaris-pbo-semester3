/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Gunaw
 */
public class FormDeliveryClass {
        
    public String nama;
    public String alamat;
    public String noHp;
    public String suratJalan;

}






